# Inspo board — Vibe Align

A living mood board. **How to use it going forward:** drop screenshots into chat anytime
(optionally with a one-line "I liked the X"). I file them here and fold recurring moves into the
design system so they show up automatically in future work. The more you tag *why*, the sharper
the output.

> Note on color: almost every reference below leans on **orange/coral, pink, or yellow**. Vibe
> Align's accent is **plum (#5D2E46)** with **mint (#9aedb7)** and **gold (#cdb876)** as the only
> two stoppers. So we borrow the *moves* (doodles, highlighters, collage, UI cards) but recolor
> them to plum/gold/mint. The orange starburst is a Claude-ecosystem motif, not ours; our
> equivalent is a plum or gold mark derived from the VA teardrop.

---

## The cross-cutting patterns you're drawn to

These showed up again and again. I'm treating them as the **Vibe Align "personality kit"** and
will reuse them:

1. **Handwritten margin annotations** (Caveat-style): "here's how", "swipe", circled words,
   little asides. Nearly every reference has them. We already use Caveat. → *Use more, and add
   hand-drawn arrows + circles/ovals around one key word per slide.*
2. **Doodle accents**: starbursts/asterisks, hand-drawn arrows, sparkles, oval "lasso" circles
   around words. → *Recolor to plum/gold. Build a small set of reusable SVG doodles.*
3. **Highlighter marker** over the single most important phrase (yellow/pink in refs). → *We
   already do this in gold/mint. Keep, maybe vary the angle.*
4. **Two-tone headlines**: black + one accent word, OR serif + sans mix in one headline
   ("The Brand *Rulebook*", "you keep re-explaining the *same task*"). → *Plum/gold accent word;
   try a serif italic for the emphasis word.*
5. **UI card overlays**: a screenshot-style card (Notes app, IG Insights, a prompt box, a CRM
   record) dropped on the slide as "proof" or "the actual prompt/result". → *Strong fit for
   CADENCE — overlay a real intake-board / contact-record card.*
6. **Real photography with cutout subjects + collage** (founder laughing, person on laptop,
   objects scattered). → *Use Mikke's real photos as cutouts; warm, documentary, never stock-smile.*
7. **Full-bleed photo + bold condensed caps headline** (white + accent), often with a scrim. →
   *Works for cover slides; we have Big Shoulders for this.*
8. **Pastel pill tags + soft icon circles** (skills/tools lists). → *Recolor to plum/mint/gold
   tints; good for "skills/tools/what you get" rows.*
9. **Numbered progress chrome** (02/12, 2/7, page dots) and **"swipe"/CTA affordances**. → *Keep
   the slide counter + swipe cue.*
10. **Sketch/hand-drawn illustration style** (Gen Academy roadmap) — fully illustrated, doodled
    icons. → *Use sparingly; heavy illustration can fight our clinical credibility.*
11. **Color-coded step columns** (#16): a horizontal row of pastel panels, one hue per step, each
    with a numbered label + illustrated icon vignette + short caption; "proof" objects (a dashboard
    mock, a donut % stat) embedded inside a column. → *Strong fit for explaining the CADENCE flow
    as a carousel cover or a single "how it works" graphic. Recolor the pastels to plum/mint/gold
    tints (don't ship the rainbow); keep one accent hue per step but pulled from our ramp.*

---

## The references (add your own "why" notes)

| # | File | What it is | Standout moves | Why you liked it |
|---|------|-----------|----------------|------------------|
| 01 | `01-stylergermain-followers.png` | "MY AI AGENT GAINED ME 16K+ FOLLOWERS" | Full-bleed B&W street photo, condensed white+coral caps, starburst doodle, IG Insights card overlay, "here's how" + arrow | _your note_ |
| 02 | `02-meghanify-flowchart.png` | "Steal your competitor's audience" flowchart | Flowchart on paper, handwritten margin notes + arrows, yellow highlighter, punchy footer line | _your note_ |
| 03 | `03-bossbaesteph-notes.png` | "PLAN 30 DAYS OF CONTENT" | Black + orange headline, yellow Notes-app card holding the actual prompt | _your note_ |
| 04 | `04-opus48-collage.png` | "Opus 4.8 just dropped. you don't need it." | Serif headline, cutout laughing woman, object collage, star doodles, "SWIPE" | _your note_ |
| 05 | `05-leadgen-pills.png` | "Lead Generation Automation" | Bold black headline + pink highlighter, pastel pill tags, soft icon circles, black footer bar w/ crown doodle | _your note_ |
| 06 | `06-techwitharia-script.png` | "you're not underqualified" | Script/handwritten headline over photo, oval lasso doodle, prompt card overlay | _your note_ |
| 07 | `07-notescard-photo.png` | "MOST PEOPLE ONLY KNOW CHAT" | Photo + Notes-app card overlay, slide counter 2/7 | _your note_ |
| 08 | `08-brand-rulebook.png` | "The Brand Rulebook" | Orange + black serif/sans mix headline, starbursts, handwritten labels in a box | _your note_ |
| 09 | `09-genacademy-doodle.png` | "BUILD THE FOUNDATION" roadmap | Fully hand-drawn doodle style, mint/teal, pink highlighter, sketched icons | _your note_ |
| 10 | `10-claude-promptpack.png` | "CLAUDE PROMPT PACK" | Top-down dark photo, huge grungy condensed orange type, handwritten white annotations | _your note_ |
| 11 | `11-obsidian-vault.png` | "What You're Actually Building" | Cartoon character, serif+purple, app screenshot, pastel pill cards, playful | _your note_ |
| 12 | `12-dontrun-sign.png` | "Don't run. You prayed for this." | Person holding a hand-lettered sign, stark and direct | _your note_ |
| 13 | `13-mainstreet-signs.png` | "Main Street Millionaire Live" | Person holding two hand-lettered signs, candid street photo | _your note_ |
| 14 | `14-wrightmode-serif.png` | "You keep re-explaining the same task." | B&W portrait, large serif headline with italic emphasis word, clean | _your note_ |
| 15 | `15-evolvingai-starburst.png` | "Claude Opus 4.8 dropped..." | Coral starburst behind subject, white condensed caps, circular logo badge, news-style | _your note_ |
| 16 | `16-intake-stepflow.png` | "The Behavioral Health Intake Revolution: A 5-Step Guide" | Color-coded pastel columns (one hue per step), numbered STEP labels, illustrated icon vignette per column, an embedded dashboard/UI mock + a donut % stat as "proof", caption under each | _liked this one — horizontal step-flow_ |

---

## What I'll build next from this (your call)
- A **`personality kit`** added to the design system: reusable plum/gold SVG doodles (starburst,
  arrow, lasso circle), a highlighter style, a UI-card-overlay component, and a cutout-photo
  treatment — so any future slide/carousel can drop them in.
- An **inspo-styled variant** of the Silent Staff Drain carousel that pushes these moves
  (handwritten arrows, a CADENCE card overlay, a cutout of Mikke) to compare against the current.
