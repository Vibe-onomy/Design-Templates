# Photo prompts & poses — Vibe Align / Mikke

For generating (AI) or shooting (real) on-brand photos of Mikke. The inspo poses you liked
(holding signs, candid at a laptop, arms-crossed confidence, hand-to-face) work great. The trick
is keeping them in the **Vibe Align world**, not the generic-coral-creator world.

## The look (lock these in every image)
- **Wardrobe:** forest/emerald green, plum, cream, oatmeal, soft denim. Avoid loud prints and
  pure white. A green top + oatmeal cardigan (your headshot) is perfect house uniform.
- **Setting:** warm, lived-in clinical-meets-home office. Plants, books, framed credentials,
  a candle, warm lamp light. Off-white/greige walls. Nothing sterile, nothing neon.
- **Light:** warm, soft, directional (window or softbox). Slight film warmth. **Never** cold
  blue, never harsh flash.
- **Mood:** direct eye contact, calm authority, a little dry humor. You're the clinician who
  has seen it all, not a hype creator.
- **Color grade:** warm with a faint plum/gold cast. We may duotone some to plum in design.
- **Framing:** leave **negative space** to one side for headlines. Shoot some looser/wider than
  feels natural so there's room to drop type.

## Real-shoot shot list (fastest path, most authentic)
Shoot these in one sitting, same outfit, against a plain warm wall + your office:
1. **Sign series** (highest value, from your inspo): hold a blank cream poster board, hand-lettered
   look. We add the words in design, OR you write them. Shoot 4 expressions: deadpan, slight
   smirk, fully serious, mid-laugh. Sign at chest height, both hands.
2. **Arms crossed**, slight smile, looking right at camera. Body angled, face to lens.
3. **At the laptop**, side angle, mid-work, not looking at camera (for "the system runs" shots).
4. **Hand to face / chin**, thoughtful, soft smile (you already have one like this).
5. **Mid-laugh, candid**, head slightly back (warmth/relatability beats).
6. **Pointing or gesturing** to the side (where a headline or stat will go).
7. **Walking / in-motion** candid if you can, looking back over shoulder.
Leave headroom and one empty side in every frame.

## AI-generation prompt templates
Paste into an image tool, swapping the bracketed bits. Add your real face reference if the tool
supports it. Always end with the negative list.

**Base style block (reuse in all):**
> Warm, natural editorial photo of a confident woman in her late 30s, shoulder-length wavy
> blonde hair, wearing a forest-green top and oatmeal cardigan. Warm lived-in home office with
> plants, books, framed certificates, soft warm lamp light. Documentary feel, soft directional
> window light, faint film warmth, shallow depth of field. Calm, authoritative, slightly dry
> expression. Plenty of negative space on the [left/right] for text. Vertical 4:5.

**Pose prompts (append one to the base block):**
- "Holding a plain cream poster-board sign at chest height with both hands, deadpan direct eye
  contact, blank sign (no text)."
- "Arms crossed, body angled, looking directly at camera with a knowing half-smile."
- "Seated at a laptop in profile, mid-work, not looking at the camera, calm focus."
- "Hand resting against chin, thoughtful soft smile, looking just past the camera."
- "Mid-laugh, candid, relaxed shoulders, genuine warmth."
- "Gesturing open-handed to the empty side of the frame as if presenting something."

**Negative / avoid (always include):**
> No cold blue tones, no harsh flash, no neon or coral color grade, no corporate stock-smile, no
> sterile white background, no busy patterns, no text, no logos, no robots/AI/tech cliches, no
> distorted hands.

## How many / what to get first
Start with the **sign series + arms-crossed + laptop** (3 setups, ~10 usable frames). That
unlocks covers, founder slides, and "proof" layouts. Drop them in chat and I'll file them as
reusable assets and cut them into the carousels.

## Photo library (live)
A first batch now lives in `assets/photos/` (see its `README.md` for the full labeled list).
Standouts: `mikke-armscrossed-systems-poster.png` (cover/founder hero, negative space left),
`mikke-walking-tan-cardigan.png`, and `mikke-laptop-green-cardigan.png`. Still worth adding when
you can: the **blank-sign series** (we letter it in design) for punchy hook covers.
